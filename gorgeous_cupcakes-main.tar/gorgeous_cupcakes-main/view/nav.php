<nav>
	<ul>
		<li><a href= "products.php">View All Products</a></li>  
		<li><a href= "product_add_form.php">Add Product</a></li>
		<li><a href= "../controller/logout_process.php">Logout</a></li>
	</ul>
</nav> <!-- end nav -->
